
#pragma once

typedef struct GarbageRecord
{
    void * data;
    int velikost;
    void * nextPtr;
} tGarbageRecord, *tGarbageRecordPtr;




void * advMalloc(int velikost);
void * advRealloc(void * destinationAdr, int velikost);
void  globalFree();

void advAddReallocMem(void * tmpVar, int velikost, void * toNULL);
void advFindAndNULL(void * toNULL);
